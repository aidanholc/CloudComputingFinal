import json
import sqlite3
from flask import jsonify, request
import argon2


from flask_restful import Api, Resource
from knn import KNNRating


class MovieGetter(Resource):
    def __init__(self):
        self.conn = sqlite3.connect('movie.db')

    
    def get(self):
        cursor = self.conn.cursor()
        movies = cursor.execute("""
            SELECT id, title
            FROM Movie
            """).fetchall()
        payload = {id:title for id, title in movies}
        return jsonify(payload)
