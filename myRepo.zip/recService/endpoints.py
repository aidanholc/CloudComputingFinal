from flask import Flask, g
from flask_restful import Api, Resource
from movieGetter import MovieGetter
from recService import RecService
from usageStats import UsageStats
import sqlite3
import time

app = Flask(__name__)
api = Api(app)


api.add_resource(MovieGetter, '/movies')
api.add_resource(RecService, '/recs')
api.add_resource(UsageStats, '/stats')


@app.before_request
def before_request():
    g.start = time.time()

@app.after_request
def after_request(response):
    diff = time.time() - g.start
    conn = sqlite3.connect('movie.db')
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO stats (response_time)
            VALUES (?)
            """, [round(float(diff),10)])
    conn.commit()
    return response


if __name__ == '__main__':
    app.run('127.0.0.1',5002, debug=True)