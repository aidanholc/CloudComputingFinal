import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix, vstack
from sklearn.neighbors import NearestNeighbors
from sklearn.model_selection import train_test_split as sklearn_train_test_split
from math import ceil, floor, sqrt

def batch(function, data, batch_size):
    batching_list = list()
    i=0
    if batch_size >= data.shape[0]:
        batching_list.append(data)
    else:
        for i in range(0, data.shape[0], batch_size):
            batching_list.append(data[i:i+batch_size])
    output = list()
    for batch in batching_list:
        output.append(function(batch))
    return output

class AverageRating:
    def __init__(self):
        self.predictions = None
        self.training_shape = None

    def fit(self, training_ratings, withZeros=False):
        predictions = None
        if withZeros:
            predictions = training_ratings.mean(axis=0)
        else:
            sums = training_ratings.sum(axis=0)
            nnz = training_ratings.getnnz(axis=0)
            nnz = [1 if n == 0 else n for n in nnz] # make sure we aren't dividing by zero
            predictions = sums / nnz
        predictions = csr_matrix(predictions, dtype=np.float32)
        self.predictions = predictions
        
    def predict(self, user_ratings):
        if self.predictions is None:
            raise Exception("Must fit before predicting")
        prediction_matrix = self.__expand_csr(self.predictions, user_ratings.shape[0])
        return prediction_matrix
    
    def __expand_csr(self, csr, n_rows):
        """
        Expands a csr matrix that is a row vector into a matrix.
        It duplicates the row passed in n_rows times.
        """
        new_data = np.tile(csr.data, n_rows)
        new_indices = np.tile(csr.indices, n_rows)
        indptr = csr.indptr
        row_length = indptr[1]
        new_indptr = np.linspace(0,row_length*n_rows, n_rows + 1)
        return csr_matrix((new_data.astype(np.float32), new_indices.astype(np.int32), new_indptr.astype(np.int32)), dtype=np.float32)


class KNNRating:
    def __init__(self, k, metric: str):
        self.k = k
        self.metric = metric
        self.neighbors = NearestNeighbors(n_neighbors=self.k, metric=self.metric, n_jobs=-1)
        self.training_ratings = None

    def fit(self, training_ratings):
        self.training_ratings = training_ratings
        max_k = training_ratings.shape[0]
        if self.k > max_k:
            print(f"k({self.k}) is greater than total samples, changing k to the number of samples({max_k})")
            self.k = max_k
        self.neighbors.fit(self.training_ratings)

    def predict(self, user_ratings):
        if self.training_ratings is None:
            raise Exception("Must fit before predicting")
        print(f"TYPE OF USER RATINGS: {type(user_ratings)}")
        if type(user_ratings) is dict:
            num_movies = self.training_ratings.shape[1]
            new_user_ratings = np.zeros(shape=(1,num_movies), dtype=float)
            for id, rating in user_ratings.items():
                print(f"RATING IN KNN: {rating}")
                print(f"USER ITEM MATRIX: {new_user_ratings}")
                new_user_ratings[0, int(id)] = rating
            user_ratings = new_user_ratings
        predictions = batch(self._predict_batch_helper, user_ratings, batch_size=5000)
        return predictions
    
    def _predict_batch_helper(self, user_ratings):
        neighbor_indices = self.neighbors.kneighbors(user_ratings, n_neighbors=self.k, return_distance=False)
        averageRating = AverageRating()
        predictions = list()
        for item in neighbor_indices:
            averageRating.fit(self.training_ratings[item])
            predictions.append(averageRating.predictions)
        return vstack(predictions)
