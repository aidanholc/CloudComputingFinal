import json
import sqlite3
from flask import jsonify, request
import argon2
import pickle
import dill
from types import MappingProxyType
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix, vstack
from sklearn.neighbors import NearestNeighbors
from sklearn.model_selection import train_test_split as sklearn_train_test_split
from math import ceil, floor, sqrt
from numpy.core.multiarray import _reconstruct
from numpy import *

from flask_restful import Api, Resource
from knn import KNNRating

class CustomUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        print(f"name: {name}, module: {module}")
        return super().find_class(__name__, name)

class RecService(Resource):
    def __init__(self):
        #print(f"name: {__name__}")
        self.conn = sqlite3.connect('movie.db')
        with open('knn_model.pkl', 'rb') as f:
            self.model = CustomUnpickler(f).load()

    def get(self):
        data = request.get_json()
        ratings = data['ratings']
       # print(f'DATA RECIEVED: {data}')
        predictions = self.model.predict(ratings)[0].todense()
        idx_predictions = np.argsort(predictions)
        idx_predictions = idx_predictions.flatten()
       # print(f"shape: {idx_predictions.shape}")
        response_predictions = dict()
        idx_predictions = idx_predictions.tolist()[0][::-1]
        for i, item in enumerate(idx_predictions[:20]):
            response_predictions[str(i)] = item
       # print(f"Response: {response_predictions}")
        return jsonify(response_predictions)