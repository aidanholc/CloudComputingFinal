from flask import Flask
from flask_restful import Api
from .auth import auth
from .view import view
from .rater import rater
from .recs import recs
from authService.authService import AuthService
import os

def create_app():
    app = Flask(__name__)
    api = Api(app)
    app.config['SECRET_KEY'] = 'some secret key'
    os.environ['SECRET_KEY'] = 'My Secret Key'
    os.environ['jwt_token'] = 'None'
    app.register_blueprint(auth, url_prefix='/')
    app.register_blueprint(view, url_prefix='/')
    app.register_blueprint(rater, url_prefix='/')
    app.register_blueprint(recs, url_prefix='/')
    api.add_resource(AuthService, '/login_form_submission')

    return app