from flask import Blueprint, render_template, request, flash, redirect
import requests
import json
import jwt
import os

auth = Blueprint('auth', __name__)
SERVICE_ENDPOINT = 'http://auth_service:5001'

# SERVICE_ENDPOINT = 'http://127.0.0.1:5001'


@auth.route('/login', methods=['GET','POST'])
def login():
    print(f'CURRENT JWT TOKEN: {os.environ["jwt_token"]}')

    if request.method == 'POST':
        payload = dict()
        payload['email'] = request.form.get('email')
        payload['username'] = request.form.get('username')
        payload['password'] = request.form.get('password')
        payload['create'] = False

        response = requests.post(url=SERVICE_ENDPOINT, json=payload)
        response_payload = json.loads(response.text)
        if os.environ['jwt_token'] != 'None': # Handle if a user is already authenticated
            user_jwt = decode_jwt(response_payload['token'])
          #  print(auth.config['SECRET_KEY'])
            flash(f'user {user_jwt} already authenticated', category='error')
            return render_template('login.html') 


        jwt_token = response_payload['token']
        if jwt_token is not None:
            os.environ['jwt_token'] = jwt_token
            decoded_jwt = decode_jwt(jwt_token)
            flash(f"Success! {request.form.get('username')} is logged in, they are user {decoded_jwt['sub']}.", category='success')
        print(response_payload)

        
    return render_template('login.html')

@auth.route('/logout')
def logout():
    #response = requests.get(url=SERVICE_ENDPOINT)
   # print("response:" + str(response.status_code))
    os.environ['jwt_token'] = 'None'
    flash('Successfully Logged out!', category='success')
    return redirect('/')

@auth.route('/sign-up', methods=['GET', 'POST'])
def sign_up():
    
    if request.method == 'POST':
        payload = dict()
        payload['email'] = request.form.get('email')
        payload['username'] = request.form.get('username')
        payload['password'] = request.form.get('password1')
        payload['create'] = True
        conf_pass = request.form.get('password2')
        success=True
        if payload['password'] != conf_pass:
            flash('Password and Confirmation password did not match match', category='error')
            success=False
        if success:
            # Need to verify on the service side
            response = requests.post(url=SERVICE_ENDPOINT, json=payload)
            response_payload = json.loads(response.text)
            print(f"response: {response_payload}")
            os.environ['jwt_token'] = response_payload['token']
            if response_payload['created'] == True:
                flash('Account Created!', category='success')
                print(f"token: {decode_jwt(response_payload['token'])}")
            else:
                flash('Error! User (probably) already exists', category='error')
    return render_template('sign_up.html')

def decode_jwt(token):
    secret = os.environ['SECRET_KEY']
    print(f'Secret key: {secret}')
    return jwt.decode(token, os.environ['SECRET_KEY'], algorithms=['HS256'])