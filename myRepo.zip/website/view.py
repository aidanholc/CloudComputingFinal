from flask import Blueprint, render_template, redirect
#from authService.authService import AuthService

view = Blueprint('view', __name__)

@view.route("/")
def home():
    return render_template("home.html")

@view.route("/init")
def initialize():
    #auth = AuthService()
   # auth.create_tables('init.sql')
    return redirect('/')