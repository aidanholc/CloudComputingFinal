from flask import Blueprint, render_template, flash, redirect
import requests
import jwt
import os
import datetime

stats = Blueprint('stats', __name__)
RATING_ENDPOINT = 'http://rating_service:5003/stats'
MOVIE_ENDPOINT = 'http://rec_service:5002/stats'
AUTH_ENDPOINT = 'http://auth_service:5001/stats'

# RATING_ENDPOINT = 'http://127.0.0.1:5003/stats'
# MOVIE_ENDPOINT = 'http://127.0.0.1:5002/stats'
# AUTH_ENDPOINT = 'http://127.0.0.1:5001/stats'

@stats.route('/stats', methods=['GET'])
def stats_method():
    if os.environ['jwt_token'] == 'None':
        flash('Not authenticated :(', category='error')
        return redirect('/')
    jwt_token = decode_jwt(os.environ['jwt_token'])
    if jwt_token['exp'] < datetime.datetime.now().timestamp():
        flash('Token expired :(', category='error')
        os.environ['jwt_token'] = 'None'
        return redirect('/')
    if jwt_token['sub'] != 10:
        flash('Not root user, you can\'t access this page', category='error')
        return redirect('/')
    
    rating_request = requests.get(url=RATING_ENDPOINT)
    rating_request = rating_request.json()

    movie_request = requests.get(url=MOVIE_ENDPOINT)
#    print(f"rating request: {str(movie_request.content)}", flush=True)
    movie_request = movie_request.json()

    auth_request = requests.get(url=AUTH_ENDPOINT)
    auth_request = auth_request.json()

    
    print(f"rating request: {rating_request}", flush=True)
    print(f"movie request: {movie_request}", flush=True)
    print(f"auth request: {auth_request}", flush=True)
    
    return render_template('stats.html', auth_response=auth_request['response_time'], auth_hits=auth_request['hits'],
                           rating_response=rating_request['response_time'], rating_hits=rating_request['hits'],
                           rec_response=movie_request['response_time'], rec_hits=movie_request['hits'])

def decode_jwt(token):
    return jwt.decode(token, os.environ['SECRET_KEY'], algorithms=['HS256'])
