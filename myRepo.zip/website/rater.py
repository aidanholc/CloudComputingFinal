from flask import Blueprint, render_template, request, flash, redirect
import requests
import json
import jwt
import os
import datetime

rater = Blueprint('rater', __name__)
RATING_ENDPOINT = 'http://rating_service:5003'
MOVIE_ENDPOINT = 'http://rec_service:5002/movies'

# RATING_ENDPOINT = 'http://127.0.0.1:5003'
# MOVIE_ENDPOINT = 'http://127.0.0.1:5002/movies'

@rater.route('/rate', methods=['GET','POST'])
def rate():
    if os.environ['jwt_token'] == 'None':
        flash('Not authenticated :(', category='error')
        return redirect('/')
    jwt_token = decode_jwt(os.environ['jwt_token'])
    if jwt_token['exp'] < datetime.datetime.now().timestamp():
        flash('Token expired :(', category='error')
        os.environ['jwt_token'] = 'None'
        return redirect('/')
    user_id = jwt_token['sub']

    response = requests.get(url=MOVIE_ENDPOINT)
    movies = response.json()
    movies_list = [(int(k), v) for k, v in movies.items() if v is not None]
    movies_list.sort(key = lambda x: x[1])

   # token = jwt.decode(os.environ['jwt_token'])
    if request.method == 'POST':
        payload = dict()
        payload['movie_id'] = request.form.get('id')
        payload['rating'] = request.form.get('rating')
        payload['user_id'] = user_id
        payload['title'] = movies[str(payload['movie_id'])]
        response = requests.post(url=RATING_ENDPOINT, json=payload)
        response = response.json()
        #if response['created'] == True:
        flash('rating added!', category='success')
        #else:
         #   flash('You already rated that movie', category='error')

#    print(f"response on front end: {response.text}")
    return render_template('rate.html', movies=movies_list)

def decode_jwt(token):
    return jwt.decode(token, os.environ['SECRET_KEY'], algorithms=['HS256'])