from flask import Blueprint, render_template, request, flash, redirect
import requests
import json
import jwt
import os
import datetime

recs = Blueprint('recs', __name__)
RATING_ENDPOINT = 'http://rating_service:5003'
MOVIE_ENDPOINT = 'http://rec_service:5002/movies'
RECOMMENDATION_ENDPOINT = 'http://rec_service:5002/recs'

# RATING_ENDPOINT = 'http://127.0.0.1:5003'
# MOVIE_ENDPOINT = 'http://127.0.0.1:5002/movies'
# RECOMMENDATION_ENDPOINT = 'http://127.0.0.1:5002/recs'

@recs.route('/recs', methods=['GET','POST'])
def rate():
    if os.environ['jwt_token'] == 'None':
        flash('Not authenticated :(', category='error')
        return redirect('/')
    jwt_token = decode_jwt(os.environ['jwt_token'])
    if jwt_token['exp'] < datetime.datetime.now().timestamp():
        flash('Token expired :(', category='error')
        os.environ['jwt_token'] = 'None'
        return redirect('/')
    user_id = jwt_token['sub']
    payload = {'user_id': int(user_id)}
    response = requests.get(url=RATING_ENDPOINT, json=payload)
    response = response.json()
    
    
    ratings = dict()
    for rating, data in response.items():
        int_rating = int(rating)
        ratings[int_rating] = data[1]
    payload = {'ratings': ratings}
    predictions = requests.get(url=RECOMMENDATION_ENDPOINT, json=payload)
    predictions = predictions.json()

    movies = requests.get(url=MOVIE_ENDPOINT)
    movies = movies.json()

    recs = list()
    for order, id in predictions.items():
        movie_name = movies[str(id)]
        recs.append(movie_name)
    

    return render_template('recs.html', recs = recs)

def decode_jwt(token):
    return jwt.decode(token, os.environ['SECRET_KEY'], algorithms=['HS256'])