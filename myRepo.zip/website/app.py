from flask import Flask
from flask_restful import Api
from auth import auth
from view import view
from rater import rater
from recs import recs
from stats import stats
import os

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'some secret key'
    os.environ['SECRET_KEY'] = 'My Secret Key'
    os.environ['jwt_token'] = 'None'
    app.register_blueprint(auth, url_prefix='/')
    app.register_blueprint(view, url_prefix='/')
    app.register_blueprint(rater, url_prefix='/')
    app.register_blueprint(recs, url_prefix='/')
    app.register_blueprint(stats, url_prefix='/')
    return app

app = create_app()



@app.after_request
def add_headers(response):
    response.headers['Access-Control-Allow-Origin'] = "*"
    response.headers['Access-Control-Allow-Headers'] =  "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"
    response.headers['Access-Control-Allow-Methods']=  "POST, GET, PUT, DELETE, OPTIONS"
    return response




if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)