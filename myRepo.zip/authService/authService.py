import sqlite3
from flask_restful import Api, Resource
from flask import jsonify, request
import hashlib
import jwt
import os
import datetime

class AuthService(Resource):
    def get(self):
        return jsonify("Hello World")
        # response from get
    
    def post(self):
        """  
        Expected data
        create:
            boolean, true to create user, false to authenticate user
        username:
            username of user
        password:
            password of user -- not yet hashed
        email:
            Email of user -- Only needed if creating user
        """
        response = dict()
        os.environ['SECRET_KEY'] = 'My Secret Key'
        #handle data
        data = request.get_json()
        hashed_pass = hashlib.sha256(data['password'].encode()).hexdigest()
        print(f"password: {hashed_pass}")
        print(data)
        cursor = self.conn.cursor()
        if data['create'] == True: # Create New user
            does_exist = cursor.execute("""
                        SELECT id
                        FROM USER
                        WHERE username = :username
                        """, {'username':data['username']})
            sql_output = does_exist.fetchall()
            if len(sql_output) == 0: # User does not exist in table, create user
                hashed_pass = hashlib.sha256(data['password'].encode()).hexdigest()
                cursor.execute("""
                        INSERT INTO User (username, email, password)
                        VALUES (?,?,?)
                        """, (data['username'], data['email'], hashed_pass))#{'username':data['username'], 'email':data['email'], 'password':hashed_pass})
                user_id = cursor.execute("""
                        SELECT id 
                        FROM USER 
                        WHERE username = :username
                        AND password = :password 
                        """, (data['username'], hashed_pass)).fetchall()[0][0]
                print(f"userid: {user_id}")
                response['created'] = True
                payload = {
                    'exp' : datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=1),
                    'iat' : datetime.datetime.now(datetime.UTC),
                    'sub' : user_id
                }
                response['token'] = jwt.encode(
                    payload,
                    os.environ['SECRET_KEY'],
                    algorithm='HS256'
                )
                response['user_id'] = user_id
            else: # User already existed, show error instead
                response['created'] = False
                response['token'] = None
                response['user_id'] = None

        else: # Authenticate Existing User
            cursor = self.conn.cursor()
            sql_output = cursor.execute("""
                        SELECT id
                        FROM User
                        WHERE username = ?
                        AND password = ?
                        """, (data['username'], hashed_pass)).fetchall()#{'username': data['username'], 'password':hashed_pass})
           #cursor.commit()
            print(f"query response: {sql_output}")
            if len(sql_output) == 1:
                user_id = sql_output[0][0]
                payload = {
                    'exp' : datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=1),
                    'iat' : datetime.datetime.now(datetime.UTC),
                    'sub' : user_id
                }
                response['token'] = jwt.encode(
                    payload,
                    os.environ['SECRET_KEY'],
                    algorithm='HS256'
                )
                response['user_id'] = user_id
            else:
                response['token'] = None
                response['user_id'] = None
            
        
        cursor.close()
        return jsonify(response)


    def __init__(self):
        print(os.getcwd())
        self.conn = sqlite3.connect('auth.db')
        #self.hasher = PasswordHasher()

    def __del__(self):
        print('deleting')
        self.conn.commit()
        self.conn.close()

    def create_tables(self, filepath):
        cursor = self.conn.cursor()
        self.executeScriptsFromFile(filepath, cursor)
        cursor.close()

    @classmethod
    def executeScriptsFromFile(cls, filename, cursor):
        """
        Execute sql queries in sql file. Intended for queries that don't expect a resposne.
        For example, CREATE, DELETE, INSERT commands.
        """
        with open(filename, 'r') as f:
            sqlFile = f.read()
        sqlCommands = sqlFile.split(';')
        for command in sqlCommands:
           cursor.execute(command)
        
            