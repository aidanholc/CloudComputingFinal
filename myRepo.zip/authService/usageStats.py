import sqlite3
from flask import jsonify, request
from flask_restful import Resource

class UsageStats(Resource):
    def __init__(self):
        self.conn = sqlite3.connect('auth.db')

    def get(self):
        cursor = self.conn.cursor()
        sql_response = cursor.execute("""
            SELECT response_time
            FROM stats
            """).fetchall()
        total_time = 0
        for response_time in sql_response:
            total_time += response_time[0]
        payload = dict()
        if len(sql_response) != 0:
            payload['response_time'] = total_time / len(sql_response)
            payload['hits'] = len(sql_response)
        else:
            payload['response_time'] = 0
            payload['hits'] = 0
        return jsonify(payload)
        

    def put(self):
         pass 

    def __del__(self):
        self.conn.commit()
        self.conn.close()