import json
import sqlite3
from flask import jsonify, request
import argon2
import pickle

from flask_restful import Resource

class RatingService(Resource):
    def __init__(self):
        self.conn = sqlite3.connect('rating.db')

    def get(self):
        data = request.get_json()
        cursor = self.conn.cursor()
        sql_response = cursor.execute("""
            SELECT movie_id, title, rating 
            FROM Interaction
            WHERE user_id = ?
            """, [data['user_id']]).fetchall()
        payload = dict()
        for id, title, rating in sql_response:
            payload[id] = [title, rating]
        return jsonify(payload)
        
        
    
    def post(self):
        data = request.get_json()
        cursor = self.conn.cursor()
        sql_response = cursor.execute("""
            SELECT *
            FROM Interaction
            WHERE user_id = ?
            AND movie_id = ?
            """, (data['user_id'], data['movie_id'])).fetchall()
        payload = dict()
        if len(sql_response) != 0:
            payload['created'] = False
        else:
            cursor.execute("""
                INSERT INTO Interaction (user_id, movie_id, rating, title)
                VALUES (?, ?, ?, ?)
                """, (data['user_id'], data['movie_id'], data['rating'], data['title']))
            payload['created'] = True
        cursor.close()
        return jsonify(payload)

    def put(self):
         pass 

    def __del__(self):
        self.conn.commit()
        self.conn.close()