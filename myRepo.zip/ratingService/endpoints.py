from flask import Flask, g, jsonify
import sqlite3
import time
from flask_restful import Api, Resource
from ratingService import RatingService
from usageStats import UsageStats


app = Flask(__name__)
api = Api(app)

api.add_resource(RatingService, '/')
api.add_resource(UsageStats, '/stats')


@app.before_request
def before_request():
    g.start = time.time()

@app.after_request
def after_request(response):
    diff = time.time() - g.start
    conn = sqlite3.connect('rating.db')
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO stats (response_time)
            VALUES (?)
            """, [round(float(diff),10)])
    conn.commit()
    return response


if __name__ == '__main__':
    app.run('127.0.0.1',5003, debug=True)

