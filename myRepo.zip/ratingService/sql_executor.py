import sqlite3


if __name__ == '__main__':
    conn = sqlite3.connect('rating.db')
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS "stats" (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        response_time NUMERIC(20,10)
    )
                """)
    # cursor.execute("""
    #     CREATE TABLE IF NOT EXISTS "Interaction" (
    #         user_id INTEGER ,
    #         movie_id INTEGER ,
    #         title VARCHAR(0, 255),
    #         rating NUMERIC(5,2)
    #     )
    #     """)
  #  cursor.execute("DROP TABLE stats")
    cursor.close()
    conn.commit()
    conn.close()

    # data = cursor.execute("""
    #     SELECT *
    #     FROM Interaction
    #     WHERE user_id = 6
    #     """).fetchall()
   # print(data)